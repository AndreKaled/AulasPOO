

import java.awt.Container;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class InserirAposento extends JFrame{
	
	private JLabel rotulo1, rotulo2, rotulo3, rotulo4;
	private JTextField texto1, texto2, texto3, texto4;
	private JButton botao1, botao2;
	
	
	public InserirAposento(){
		
		
		super("Inserir aposento");
		
		//inicializando os componentes
		rotulo1 = new JLabel("C�digo");
		rotulo2 = new JLabel("Descri��o");
		rotulo3 = new JLabel("N�mero");
		rotulo4 = new JLabel("Valor");
		
		texto1 = new JTextField();
		texto2 = new JTextField();
		texto3 = new JTextField();
		texto4 = new JTextField();
		
		botao1 = new JButton("Ok");
		botao2 = new JButton ("Cancelar");
		
		// criando componentes essencias
		
		Container cont = getContentPane();
		
		// adicionando componentes
		
		cont.add(rotulo1);
		cont.add(rotulo2);
		cont.add(rotulo3);
		cont.add(rotulo4);
		
		cont.add(texto1);
		cont.add(texto2);
		cont.add(texto3);
		cont.add(texto4);
		
		cont.add(botao1);
		cont.add(botao2);
		
		
		// gerenciando layout
		
		setLayout(null);
		
	    rotulo1.setBounds(10, 40, 70, 50);
	    rotulo2.setBounds(10, 90, 70, 50);
	    rotulo3.setBounds(210, 40, 70, 50);
	    rotulo4.setBounds(210, 90, 70, 50);
	    
	    texto1.setBounds(70, 50, 50, 20);
	    texto2.setBounds(70, 100, 50, 20);
	    texto3.setBounds(270, 50, 50, 20);
	    texto4.setBounds(270, 100, 50, 20);
	   
	    botao1.setBounds(150, 160, 100, 30);
	    botao2.setBounds(260, 160, 100, 30);
	    
		setSize(400, 250);	
		setVisible(true);
		
	}
	
	public static void main(String[] args){
		
		new InserirAposent();
		
	}
}








public class Hospede {
	
	private int codigo;
	private String nome;
	private String cpf;
	private String telefone;
	private String rg;
	
	
	
	
	public Hospede() {
		
	}
	public Hospede(int codigo, String nome, String cpf, String telefone, String rg) {
		
		this.codigo = codigo;
		this.nome = nome;
		this.cpf = cpf;
		this.telefone = telefone;
		this.rg = rg;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	public String getRg() {
		return rg;
	}
	public void setRg(String rg) {
		this.rg = rg;
	}
	

}



public class Conta {

	private int codigo;
	private double valortotal;
	private boolean pago;
	
	
	public Conta(){
		
	}
	
	public Conta(int codigo, double valortotal, boolean pago) {
	
		this.codigo = codigo;
		this.valortotal = valortotal;
		this.pago = pago;
	}
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public double getValortotal() {
		return valortotal;
	}
	public void setValortotal(double valortotal) {
		this.valortotal = valortotal;
	}
	public boolean isPago() {
		return pago;
	}
	public void setPago(boolean pago) {
		this.pago = pago;
	}
	
	
	
}



public class Funcionario {
	
	private int codigo; 
	private double valor; 
	private String descricao;
	private int numero;
	
	public Funcionario(){
	
	}
	
	public Funcionario(int codigo, double valor, String descricao, int numero){
		
		this.codigo = codigo;
		this.descricao = descricao;
		this.valor = valor;
		this.numero = numero;
		
		
	}
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}
	
	
	
	

}




public class Aposento {
	
	private int codigo;
	private double valor; 
	private String descricao;
	private int numero;
	
	public Aposento(){
		
	}
	
	public Aposento(int codigo, double valor, String descricao, int numero){
		
		this.codigo = codigo;
		this.valor = valor; 
		this.descricao = descricao;
		this.numero = numero;
		
	}
	
	public int getCodigo() {
		return codigo;
	}
	public void setCodigo(int codigo) {
		this.codigo = codigo;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public int getNumero() {
		return numero;
	}
	public void setNumero(int numero) {
		this.numero = numero;
	}

}






import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

public class Aposentos extends JFrame{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	JButton btnNovo,btnAlterar,btnRemover;
	JScrollPane scroll;
	JTable tabela;
	String[] dados = {"", "", "", ""};
	Object[][] info = {{"1","","",""},{"","","",""}};
	JPanel panel = (JPanel) getContentPane();
	
	public Aposentos(){
		setSize(420,420);
		setLayout(null);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		configurandoComponentes();
		setVisible(true);
	}
	
	public void configurandoComponentes(){
		btnNovo = new JButton("Novo");
		btnAlterar = new JButton("Alterar");
		btnRemover = new JButton("Remover");

		btnNovo.setBounds(10,10,100,20);
		btnAlterar.setBounds(120,10,100,20);
		btnRemover.setBounds(230,10,100,20);
		
		tabela = new JTable(info,dados);
		scroll = new JScrollPane(tabela);
		
		scroll.setBounds(25,50,350,300);
		
		panel.add(btnNovo);
		panel.add(btnAlterar);
		panel.add(btnRemover);
		panel.add(scroll);
		
		btnNovo.addActionListener(new ActionListener(){

			@Override
			public void actionPerformed(ActionEvent arg0) {


				new InserirAposent();
				
			}
			
		});
	
   }
	
}